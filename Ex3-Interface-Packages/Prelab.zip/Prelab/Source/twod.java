package shape2d;

public interface twod{
  public double area();
  public double perimeter();
}
