package shape3d;

public interface threed{
    public double volume();
    public double surfaceArea();
}
